# ⛏️ Mining Adventure 3D

A fully playable browser mining game inspired by the supplied UI reference.

## Play
- **WASD / Arrow keys** — move
- **Mouse drag** — rotate camera
- **Click or E / Space** — mine the nearest ore
- **Sell Ore** — sell everything in your backpack
- **Worlds** — unlock harder mining areas
- **Upgrades** — improve power, backpack, sell value, and speed
- Progress automatically saves to `localStorage`

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and this `README.md`.
3. Go to **Settings → Pages**.
4. Set the source to the `main` branch and `/ (root)`.
5. Open the published Pages URL.

No build step is required. Three.js is loaded from jsDelivr.

## Included systems
- Third-person 3D movement and camera
- Procedural low-poly mining world
- Five worlds
- Five ore types
- Mining health/damage
- Inventory and backpack capacity
- Selling and currency
- XP and leveling
- Quest progress and rewards
- Four upgrade categories
- World unlock requirements
- Save/load with browser localStorage
- Desktop mouse/keyboard controls
- Basic mobile touch controls

## Notes
This is intentionally dependency-light: the repository only needs the HTML file to run on GitHub Pages.
